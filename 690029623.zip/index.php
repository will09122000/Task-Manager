<?php
header("location: login.php");
exit();
