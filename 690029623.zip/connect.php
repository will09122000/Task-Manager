<?php
define(host,"emps-sql.ex.ac.uk");
define(username,"wc352");
define(password,"wc352");
define(database,"wc352");
define(port,3306);

